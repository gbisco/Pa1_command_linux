#include"PA1header.h"
#include <iostream>
#include <string>
#include <fstream>
#include <time.h>

using namespace std;

void Game::populateList(string c, string n) {
	Node *temp = new Node;
	temp->command = c;
	temp->ans = n;

	//checking empty list case
	if (head == NULL) {
		head = temp;
		tail = temp;
		cout << "adding command: " << c << endl;
	}
	else {
		tail->next = temp;
		tail = tail->next;
		cout << "adding command: " << c << endl;
	}
}

Game::Game() {
	head = NULL;
	tail = NULL;
    size = 0;
	cout << "constructing Game object..." << endl;

	//string to be passed to populate
	string c, n;
	ifstream ifile;
	ifile.open("commands.csv");

	//read the file
	while (getline(ifile, c, ',') && getline(ifile, n, '\n')) {
		populateList(c, n);
		size++;
	}
	ifile.close();
}

void Game::delNode() {
	cout << "warning Nodes should be deleted before exiting the program!" << endl;
	//setermining command to be deleted
	string delCommand;
	cout << "command to be deleted:" << endl;
	cin >> delCommand;
	//setting traversing temp
	Node *temp = head;
	while (temp != NULL) {
		if ((delCommand.compare(temp->command)) == 0) {
			temp->command = temp->next->command;
			temp->ans = temp->next->ans;
			temp->next = temp->next->next;
			cout << delCommand << " deleted successfully..." << endl;
			return;
		}
		temp = temp->next;
	}
	cout << "node not found..." << endl;
}

void Game::insertNode() {
	cout << "Nodes should be added before exiting the program!" << endl;
	//defining Node to be inserted into the list
	Node *newNode = new Node;

	cout << "command name: ";
	cin >> newNode->command;
	cout << "\ndescription; ";
	cin >> newNode->ans;
	cout << endl;
	
	//appending node
	tail->next = newNode;
	tail = tail->next;
	cout << "node added..." << endl;
}

string Game::getNodeAns(int position) {
	//creating node to be used in question
	Node *qNode = head;
	//creating count for interations
	int count = 0;
	for (count = 0; count < position; count++) {
		//traversing
		qNode = qNode->next;
	}

	return qNode->ans;
}

string Game::getNodeCom(int position) {
	//creating node to be used in question
	Node *qNode = head;
	//creating count for interations
	int count = 0;
	for (count = 0; count < position; count++) {
		//traversing
		qNode = qNode->next;
	}

	return qNode->command;
}

int Game::playGame() {
	srand(time(0));
	//strings for questions and right answers
	string qAns, qCom, rCom;
	//game size
	int rounds = 0;
	do {
		cout << "\nAmount of questions you wish to practice (3-30): " << endl;
		cin >> rounds;
	} while (rounds > 30 || rounds < 3);
	system("cls");
	//int count for keeping track of rounds
	int count = 0;
	//int score for keeping track of scores
	int score = 0;
	//int for storing user answer
	int uAns = 0;
	//int to randomizing place of right answer(1,2, or 3)
	int random = 0, rand2 = 0;
	//game starts
	for (count = 0; count < rounds; count++) {
		random = rand() % 3 + 1;
		rand2 = rand() % size + 1;
		qAns = getNodeAns(rand2);
		rCom = getNodeCom(rand2);

		//case 1
		if (random == 1) {
			cout << "Q:\n" << qAns;
			cout << "\n1. " << rCom<<endl;
			//do while in case the same number is randomized 2x in a row
			do {
				qCom = getNodeCom((rand() % size + 1));
			} while ((rCom.compare(qCom)) == 0);
			cout << "2. " << qCom << endl;
			do {
				qCom = getNodeCom((rand() % size + 1));
			} while ((rCom.compare(qCom)) == 0);
			cout << "3. " << qCom << endl;
			cout << "A: ";
			cin >> uAns;
			if (uAns == 1) {
				score++;
				cout << "Good Job!" << endl;
				cout << "score: " << score << endl;
			}
			else {
				score--;
				cout << "Wrong Answer" << endl;
				cout << "score: " << score << endl;
			}
		}

		//case 2 
		else if (random == 2) {
			cout << "Q:\n" << qAns;
			//do while in case the same number is randomized 2x in a row
			//wrong one
			do {
				qCom = getNodeCom((rand() % size + 1));
			} while ((rCom.compare(qCom)) == 0);
			cout << "\n1. " << qCom << endl;
			//right answer
			cout<<"2. " << rCom << endl;
			//wrong one
			do {
				qCom = getNodeCom((rand() % size + 1));
			} while ((rCom.compare(qCom)) == 0);
			cout << "3. " << qCom << endl;
			cout << "A: ";
			cin >> uAns;
			if (uAns == 2) {
				score++;
				cout << "Good Job!" << endl;
				cout << "score: " << score << endl;
			}
			else {
				score--;
				cout << "Wrong Answer" << endl;
				cout << "score: " << score << endl;
			}
		}

		//case 3
		else if (random == 3) {
			cout << "Q:\n" << qAns;
			//do while in case the same number is randomized 2x in a row
			//wrong one
			do {
				qCom = getNodeCom((rand() % size + 1));
			} while ((rCom.compare(qCom)) == 0);
			cout << "\n1. " << qCom << endl;
			//wrong one
			do {
				qCom = getNodeCom((rand() % size + 1));
			} while ((rCom.compare(qCom)) == 0);
			cout << "2. " << qCom << endl;
			//right answer
			cout << "3. " << rCom << endl;

			cout << "A: ";
			cin >> uAns;
			if (uAns == 3) {
				cout << "Good Job!" << endl;
				score++;
				cout << "score: " << score << endl;
			}
			else {
				cout << "Wrong Answer" << endl;
				score--;
				cout << "score: " << score << endl;
			}
		}

	}
	cout << "\n\n				...game-over...\nyour final score: "<<score << endl;
	return score;
}

void Game::updateList() {
	ofstream ofile;
	ofile.open("commands.csv", ios::trunc);
	Node *temp = head;
	int count = 0;
	for (count = 0; count < size; count++)
	{
		ofile << temp->command << "," << temp->ans << endl;
		temp = temp->next;
	}
	ofile.close();
}

Game::~Game() {
	updateList();
	while (head != tail) {
		Node *temp = head;
		head = head->next;
		delete(temp);
	}
	head = nullptr;
	tail = nullptr;
}

void readProfiles(uProfiles arr[], int arrSize) {
	//opening file
	ifstream ifile;
	ifile.open("profiles.csv");
	//int count for not overloading
	int count = 0;

	while ((getline(ifile, arr[count].name, ',') && ifile>>arr[count].points) && (count < arrSize)) {
		count++;
	}
	ifile.close();
}

void updateProfile(uProfiles arr[], int arrSize, int score, string name) {
	int count = 0;
	//finding if name is already in the array
	for ( count = 0; (count < arrSize)||((arr[count].name).size() == 0); count++) {
		if (name.compare(arr[count].name) == 0) {
			arr[count].points += score;
			score = 0;
		}
	}
	if (score != 0) {
		arr[count+1].name = name;
		arr[count + 1].points = score;
	}
	//open profile file to override contrents (trunc mode)
	ofstream ofile;
	ofile.open("profiles.csv", ios::trunc);

	for (count = 0; (count < arrSize) || ((arr[count].name).size() == 0); count++) {
		ofile << arr[count].name << "," << arr[count].points << "/n";
	}
	ofile.close();
}
	