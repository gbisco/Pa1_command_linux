//Gabriel Bisco Reinato
//Cpts223
//PA1

/*ADVANTAGES / DISADVANTAGES LINKED LIST :
1)using a linked list allows the data to be dynamically allocatedwithout overloading
2)linked lists can be "messed up" by accidentaly breaking a link in the chain
* /
/*ADVANTAGES / DISADVANTAGES ARRAY :
1)using an array of classes allow us to have more control over changes in the array by using private variables and functions
2)using an array of classes might require more work and its probably less efficient
*/
#include "PA1header.h"
#include<iostream>
#include<string>
#include<time.h>
using namespace std;
int main(void) {
	srand(time(0));
	//creating integer for menu loop
	int opt = 0;
	//creating score int for record
	int score = 0;
	//creating string for name record
	string name;
	//creating class object
	Game game;
	//creating array of profiles
	uProfiles arr[100];
	//reading profiles from file
	readProfiles(arr, 100);
	//system command cleanning check of constructor
	system("pause");
	system("cls");

	while (opt != 6) {
		cout << "1. Game Rules\n2. Play Game\n3. Load Previous Game\n4. Add Command\n5. Remove Command\n6. Exit" << endl;
		cin >> opt;

		switch (opt) {
		case 1:
			system("cls");
			cout << "Match the right answer to the Linux command!\nFor every correct answer you will be awarded 1 point.\nEvery answer you miss you will loose a point.\nHave Fun!" << endl;
			system("pause");
			system("cls");
			break;

		case 2:
			system("cls");
			cout << "Welcome! Have fun Learning Linux commands!" << endl;
			score += game.playGame();
			cout << "Name: ";
			cin >> name;
			system("cls");
			break;

		case 3:
			system("cls");
			cout << "name: " << name << endl;
			cout << "points: " << score << endl;
			system("pause");
			system("cls");
			break;

		case 4:
			system("cls");
			game.insertNode();
			system("pause");
			system("cls");
			break;

		case 5:
			system("cls");
			game.delNode();
			system("pause");
			system("cls");
			break;

		case 6:
			cout << "updating list..." << endl;
			game.~Game();
			cout << "updating profiles..." << endl;
			updateProfile(arr, 100, score, name);
			cout << "Bye!" << endl;
			break;
		}
	}

	return 0;
}



